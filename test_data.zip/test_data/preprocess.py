# The code is shared on SDSC Github
from PIL import Image
import os
import numpy as np
import random

dir1 = "images\\"

imgvectors = []
labels = []
Nfolders = next(os.walk(dir1))[1]
for i in range(len(Nfolders)):
    dir2 = dir1 + Nfolders[i] + "\\"
    Nimgs = next(os.walk(dir2))[2]
    print("Checking folders " + str(i+1) + "/" + str(len(Nfolders)) + ". With " + str(len(Nimgs)) + "images.")
    temp = np.zeros((len(Nimgs), len(Nfolders)),dtype=np.float32)
    temp[:,i] = 1
    if i==0:
        labels = temp
    else:
        labels = np.vstack((labels,temp))

    for j in range(len(Nimgs)):
        dir3 = dir2 + Nimgs[j]
        img = Image.open(dir3)
        width, height = img.size
        arr1 = np.array(img).reshape(width*height,-1)
        if i==0 and j==0:
            imgvectors = (arr1[:,0].transpose())/255
        else:
            imgvectors = np.vstack((imgvectors,(arr1[:,0].transpose())/255))

if os.path.exists("TestData")==False:
    os.mkdir("TestData")

rand_num = [x for x in range(imgvectors.shape[0])]
random.shuffle(rand_num)
imgvectors = imgvectors[rand_num,:]
labels = labels[rand_num,:]
np.savetxt('TestData\imgvectors.txt', imgvectors)
np.savetxt('TestData\labels.txt', labels)
print('Test data saved !')




