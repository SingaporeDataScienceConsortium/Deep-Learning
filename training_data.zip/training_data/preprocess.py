# The code is shared on SDSC Github
# Aim: This code aims to engineer the input data. It reads all input images and
# convert them to something that can be easily accessed by the neural network

from PIL import Image
import os
import numpy as np
import random


dir1 = "images\\"

# declare the final results we want to save
imgvectors = []
labels = []

# check the number of folders
Nfolders = next(os.walk(dir1))[1]

# read through all folders (categorized images)
for i in range(len(Nfolders)):

    # check the number of images and their names in each folder
    dir2 = dir1 + Nfolders[i] + "\\"
    Nimgs = next(os.walk(dir2))[2]

    print("Checking folders " + str(i+1) + "/" + str(len(Nfolders)) + ". With " + str(len(Nimgs)) + "images.")

    # use temp to temporarily store the labels for a single class
    temp = np.zeros((len(Nimgs), len(Nfolders)),dtype=np.float32)
    temp[:,i] = 1
    # the shape of temp now is
    # number of row: Number of images in each folder
    # number of colums: Number of classes (here we have 5 classes)
    #-------------------------------------------------------------
    # now temp looks like this
    # for class 1, temp =
    # [[1,0,0,0,0],
    #  [1,0,0,0,0],
    #  ...
    #  [1,0,0,0,0]]
    #-------------------------------------------------------------
    # for class 4, temp =
    # [[0,0,0,1,0],
    #  [0,0,0,1,0],
    #  ...
    #  [0,0,0,1,0]]
    #-------------------------------------------------------------

    # the following code put all labels together
    if i==0:
        labels = temp
    else:
        labels = np.vstack((labels,temp))

    # for each folder/class, the following code converts each 2D image to
    # 1D vector and vertically stack all 1D vectors together
    for j in range(len(Nimgs)):
        dir3 = dir2 + Nimgs[j]

        # open each image and convert it to 1D vector
        img = Image.open(dir3)
        width, height = img.size
        arr1 = np.array(img).reshape(width*height,-1)

        # stack all 1D vectors together
        if i==0 and j==0:
            imgvectors = (arr1[:,0].transpose())/255
        else:
            imgvectors = np.vstack((imgvectors,(arr1[:,0].transpose())/255))
    # for the final 2D matrix (imgvectors), each row represents an image
    # the shape of imgvectors now is
    # number of row: Number of all images
    # number of colums: Number of pixels in each image

# create a new folder to store the final engineered result
if os.path.exists("TrainingData")==False:
    os.mkdir("TrainingData")

# shuffle the data
rand_num = [x for x in range(imgvectors.shape[0])]
random.shuffle(rand_num)
imgvectors = imgvectors[rand_num,:]
labels = labels[rand_num,:]

# save the final result
np.savetxt('TrainingData\imgvectors.txt', imgvectors)
np.savetxt('TrainingData\labels.txt', labels)
print('Result saved !')




